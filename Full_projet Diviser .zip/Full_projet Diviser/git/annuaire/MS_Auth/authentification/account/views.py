from lib2to3.pgen2 import driver

from celery.worker.state import requests
from django.contrib.auth.hashers import make_password
from django.http import JsonResponse, HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.core.validators import validate_email
from django.contrib.auth.models import User
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.core.mail import EmailMessage
from rest_framework.decorators import api_view
from rest_framework_simplejwt.tokens import RefreshToken

from .models import Contact
from .form import ContactForm, CustomUserChangeForm, CustomForm, CustomPasswordChangeForm
# Create your views here.

from django.shortcuts import render, get_object_or_404, redirect
from .models import Contact
# Assurez-vous d'importer votre formulaire de contact
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.db import connection
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.contrib import messages
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
import jwt
import jwt

def log_out(request):
    logout(request)
    return redirect('sing_in')




def welcome(request):
    return render(request, 'welcome.html')


from rest_framework.response import Response

from django.http import JsonResponse



@api_view(['GET', 'POST'])
def sing_in(request):
    if request.method == 'POST':
        email = request.data.get('email', None)
        password = request.data.get('password', None)

        user = User.objects.filter(email=email).first()
        if user:
            auth_user = authenticate(username=user.username, password=password)
            if auth_user:
                login(request, auth_user)
                # Generate a JWT with user information
                jwt_payload = {
                    'user_email': user.email,
                    'password': password,
                    'is_staff': user.is_staff,
                    'is_active': user.is_active,
                    'is_admin': user.is_superuser,
                }

                # Encode the payload into a JWT
                encoded_jwt = jwt.encode(jwt_payload, 'secret', algorithm='HS256')

                # Set an HTTP cookie with the encoded JWT
                response = JsonResponse({
                    'refresh': 'secret',
                    'access': encoded_jwt,
                })

                response.set_cookie('jwt_token', encoded_jwt, samesite='None', secure=True,httponly=True)
                # Set the content type to JSON
                response['Content-Type'] = 'application/json'

                # Perform the redirection
                response['Location'] = 'http://127.0.0.1:8080/'
                response.status_code = 302

                return response  # Retourne la réponse avec les cookies et la redirection

                return response

                """# Vérifiez si la demande provient du frontend (AJAX) ou d'un navigateur direct
                if request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest':
                    return response  # Si c'est une demande AJAX, retournez simplement la réponse JSON
                else:  HttpResponseRedirect('http://127.0.0.1:8080/') """

            else:
                return JsonResponse({'error': 'Incorrect password'}, status=401)
        else:
            return JsonResponse({'error': 'User does not exist'}, status=404)
    elif request.method == 'GET':
        # Render a login page for GET requests
        return render(request, 'login.html')


def sing_up(request):
    error = False
    message = ""
    if request.method == "POST":
        name = request.POST.get('name', None)
        email = request.POST.get('email', None)
        password = request.POST.get('password', None)
        repassword = request.POST.get('repassword', None)
        # Email
        try:
            validate_email(email)
        except:
            error = True
            message = "Enter un email valide svp!"
        # password
        if error == False:
            if password != repassword:
                error = True
                message = "Les deux mot de passe ne correspondent pas!"
        # Exist
        user = User.objects.filter(Q(email=email) | Q(username=name)).first()
        if user:
            error = True
            message = f"Un utilisateur avec email {email} ou le nom d'utilisateur {name} exist déjà'!"
        # register
        if error == False:
            user = User(
                username=name,
                email=email,
            )
            user.save()

            user.password = password
            user.set_password(user.password)
            user.save()

            return redirect('sing_in')

            # print("=="*5, " NEW POST: ",name,email, password, repassword, "=="*5)

    context = {
        'error': error,
        'message': message
    }
    return render(request, 'register.html', context)

