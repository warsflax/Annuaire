# forms.py
from django.contrib.auth.forms import UserChangeForm, PasswordChangeForm
from django import forms
from .models import Contact
# forms.py
from django import forms
from django.contrib.auth.forms import UserChangeForm
from .models import CustomUser
class CustomUserChangeForm(UserChangeForm):
    password = None
    class Meta:
        model = CustomUser
        fields = ('username', 'first_name', 'last_name', 'email' )

        labels = {
            'username': 'Nom d\'utilisateur',
            'first_name': 'Prénom',
            'last_name': 'Nom de famille',
            'email': 'Adresse e-mail',

        }
        ''''''

class CustomPasswordChangeForm(PasswordChangeForm):
    class Meta:
        model = CustomUser
        fields = ('password')
        widgets = {
            'password': forms.PasswordInput(render_value=True),
        }
class CustomForm(UserChangeForm):
    password = None
    class Meta:
        model = CustomUser
        fields = ('username', 'first_name', 'last_name', 'email', 'is_active', 'is_staff', 'is_superuser')
        labels = {
            'username': 'Nom d\'utilisateur',
            'first_name': 'Prénom',
            'last_name': 'Nom de famille',
            'email': 'Adresse e-mail',
            'is_active': 'Compte actif',
            'is_staff': 'editeur',
            'is_superuser': 'Administrateur',
        }

class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = ['nom', 'prenom', 'numero_telephone']
