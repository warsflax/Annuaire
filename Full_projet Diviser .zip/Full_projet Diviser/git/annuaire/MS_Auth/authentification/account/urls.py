from django.contrib import admin
from django.urls import path, include
from account.views import (
    sing_in, sing_up,welcome,log_out
)
urlpatterns = [

    path('api/login/', sing_in, name='sing_in'),
    path('', sing_in, name='sing_in'),
    path('register', sing_up, name='sing_up'),

    path('logout', log_out, name='log_out'),
    #path('update-password', update_password, name='update_password'),
    #path('contacts', liste_contacts, name='liste_contacts'),
    #path('users', users_Liste, name='users_Liste'),
    #path('modifier_user/<int:user_id>/', modifier_user, name='modifier_user'),
    #path('ajouter-contact', ajouter_contact, name='ajouter_contact'),
    #path('modifier_contact/<int:contact_id>/', modifier_contact, name='modifier_contact'),
    # Vos autres URL
    #path('modifier_profil/', modifier_profil, name='modifier_profil'),
    #path('modifier_password/', modifier_password, name='modifier_password'),
    path('welcome/', welcome, name='welcome'),
]
